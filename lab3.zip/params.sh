# max number of threads per block is 1024
export GRID='14 14 64'
export BLOCK='8 8 4'